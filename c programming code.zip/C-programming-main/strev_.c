#include<stdio.h>
#include<string.h>

int main(){

    char a[30]="kanishk";
    strrev(a);
printf("%s",a);

     return 0;
}



