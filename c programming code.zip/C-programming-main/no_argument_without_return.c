#include<stdio.h>
void sum(void);
void main()
{
    sum();
}
void sum()
{
int a=9,b=1;
int sum=a+b;
printf("sum is %d ",sum);
}