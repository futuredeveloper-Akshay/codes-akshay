#include<stdio.h>

int main(){
    int i,a[102];
    for(i=1;i<=10;i++)
    {
        a[i]=2*i;
        printf("\n2 x %d =%d",i,a[i] );
    }
    
     return 0;
}