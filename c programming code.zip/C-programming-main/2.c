#include<stdio.h>
int main(){
printf("size of int is %d",sizeof(int));
printf("\nsize of float is %d",sizeof(float));
printf("\nsize of double is %d",sizeof(double));
printf("\nsize of long double is %d",sizeof(long double));
printf("\nsize of short int is %d",sizeof(short int));
}