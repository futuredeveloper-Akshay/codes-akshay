#include<stdio.h>
#include<string.h>

int main(){

    char a[30]="kanishk";
    char b[30];
    strcpy(b,a);
printf("%s",b);

     return 0;
}