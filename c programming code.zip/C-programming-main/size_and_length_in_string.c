#include<stdio.h>
#include<string.h>

int main(){

    char a[]="kanishk";
    printf(" size is %d\n",sizeof(a));
printf("length is %d",strlen(a));


     return 0;
}