#include<stdio.h>
int main(){
int i,j,m,n;
for(i=20;i<=50;i++)

{
for(j=1;j<=10;j++)
{
printf("multiplication of %d X %d =%d\n",i,j,i*j);
}
}


return 0;
}

