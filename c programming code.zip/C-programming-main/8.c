#include<stdio.h>
int main() {
        int i,n,c=0;
        printf("Enter the number that you want to check\n");
        scanf("%d",&n);
        for(i=1;i<n;i++){
            if(i%2==0){
                c++;  } }
        if(i=2)
        printf("Number is prime");
        else
        printf("Number is not prime");
        
     return 0;
}