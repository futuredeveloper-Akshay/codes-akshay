#include<stdio.h>
#include<string.h>
int main(){
    char a1[100],a2[100];
    int length1,length,length2,i,j,count=0, not_count=0;
    printf("Enter first string\n");
    gets(a1);
    printf("Enter second string\n");
    gets(a2);
    length1=strlen(a1);
    length2=strlen(a2);
    if(length1==length2){
        length=length1;
        for(i=0;i<length;i++)
        {
            
        }
    }

}