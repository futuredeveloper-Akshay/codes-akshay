#include<stdio.h>
#include<string.h>
int main(){
int count=0;
char a[30]="Kanishk";
char b[30]="Patel";
strcat(a,b);

printf("%s",a);
return 0;
}

