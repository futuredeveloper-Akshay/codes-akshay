#include<stdio.h>
#include<string.h>

int main(){
    int k;

    char a[30]="kanishk";
    char b[30]="kanishk";
   k= strcmp(b,a);
    if(k==0)
    {
        printf("ewqual");
    }
    else{
        printf("nnnnnnnewqual"); 
    }
     return 0;
}
