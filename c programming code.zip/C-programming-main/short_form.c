#include<stdio.h>

int main(){
    char a[10],b[10],c[10];
    printf("Enter the string 1 :");
    gets(a);
    printf("Enter the string 2 :");
    gets(b);
    printf("Enter the string 3 :");
    gets(c);
    printf("%c",a[0]);
    printf(".");
      printf("%c",b[0]);
      printf(" ");
          printf("%s",c);
     return 0;
}